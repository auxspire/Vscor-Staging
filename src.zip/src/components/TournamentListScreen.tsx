// src/components/TournamentListScreen.tsx
// Tournament list + inline "Create Tournament" form.
// @ts-nocheck

import React, { useEffect, useState, FormEvent } from "react";
import { supabase } from "../lib/supabaseClient";
import {
  ArrowLeft,
  Plus,
  Trophy,
  Globe2,
  Calendar,
  Loader2,
  Flag,
} from "lucide-react";

export type TournamentStatus = "UPCOMING" | "LIVE" | "COMPLETED" | "ARCHIVED";

export type TournamentSummary = {
  id: string;
  name: string;
  slug?: string | null;
  logoUrl?: string | null;
  country?: string | null;
  season?: string | null;
  status?: TournamentStatus | string | null;
  startDate?: string | null;
  endDate?: string | null;
  venue?: string | null;
};

type Props = {
  tournaments: TournamentSummary[]; // kept for compatibility, but we load fresh from DB
  onBack: () => void;
  onTournamentClick: (t: TournamentSummary) => void;
};

const TournamentListScreen: React.FC<Props> = ({
  onBack,
  onTournamentClick,
}) => {
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<TournamentSummary[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [showCreate, setShowCreate] = useState(false);
  const [creating, setCreating] = useState(false);

  // form fields
  const [name, setName] = useState("");
  const [season, setSeason] = useState("");
  const [country, setCountry] = useState("");
  const [status, setStatus] = useState<TournamentStatus>("UPCOMING");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);

      try {
        const { data, error: dbError } = await supabase
          .from("tournaments")
          .select(
            `
            id,
            name,
            slug,
            logo_url,
            country,
            season,
            status,
            start_date,
            end_date,
            venue
          `
          )
          .order("created_at", { ascending: false });

        if (dbError) {
          console.error("[TournamentListScreen] load error:", dbError);
          if (!cancelled) {
            setError("Could not load tournaments.");
          }
          return;
        }

        const mapped: TournamentSummary[] =
          (data ?? []).map((row: any) => ({
            id: row.id,
            name: row.name,
            slug: row.slug,
            logoUrl: row.logo_url,
            country: row.country,
            season: row.season,
            status: row.status,
            startDate: row.start_date,
            endDate: row.end_date,
            venue: row.venue,
          })) ?? [];

        if (!cancelled) {
          setItems(mapped);
        }
      } catch (e) {
        console.error("[TournamentListScreen] unexpected load error:", e);
        if (!cancelled) {
          setError("Unexpected error while loading tournaments.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const resetForm = () => {
    setName("");
    setSeason("");
    setCountry("");
    setStatus("UPCOMING");
    setStartDate("");
    setEndDate("");
  };

  const handleCreateTournament = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Tournament name is required.");
      return;
    }

    setError(null);
    setCreating(true);

    try {
      const insertPayload: any = {
        name: name.trim(),
        season: season || null,
        country: country || null,
        status,
        start_date: startDate || null,
        end_date: endDate || null,
        logo_url: null,
        venue: null,
      };

      const { data, error: insertError } = await supabase
        .from("tournaments")
        .insert(insertPayload)
        .select(
          `
          id,
          name,
          slug,
          logo_url,
          country,
          season,
          status,
          start_date,
          end_date,
          venue
        `
        )
        .maybeSingle();

      if (insertError) {
        console.error(
          "[TournamentListScreen] create tournament error:",
          insertError
        );
        setError(insertError.message || "Could not create tournament.");
        return;
      }

      if (data) {
        const created: TournamentSummary = {
          id: data.id,
          name: data.name,
          slug: data.slug,
          logoUrl: data.logo_url,
          country: data.country,
          season: data.season,
          status: data.status,
          startDate: data.start_date,
          endDate: data.end_date,
          venue: data.venue,
        };

        setItems((prev) => [created, ...prev]);
        resetForm();
        setShowCreate(false);
      }
    } catch (e: any) {
      console.error("[TournamentListScreen] unexpected create error:", e);
      setError("Unexpected error while creating tournament.");
    } finally {
      setCreating(false);
    }
  };

  const renderHeader = () => {
    return (
      <div className="px-4 pt-4 pb-3 flex items-center gap-3 border-b border-slate-200 bg-white">
        <button
          onClick={onBack}
          className="p-2 rounded-full hover:bg-slate-100 active:bg-slate-200 transition"
        >
          <ArrowLeft className="w-5 h-5 text-slate-700" />
        </button>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-purple-100 flex items-center justify-center">
            <Trophy className="w-5 h-5 text-purple-700" />
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
              Tournaments
            </p>
            <h1 className="text-sm font-semibold text-slate-900">
              Manage Competitions
            </h1>
          </div>
        </div>
      </div>
    );
  };

  const renderCreateForm = () => {
    if (!showCreate) {
      return (
        <div className="px-4 pt-3 pb-2 bg-white">
          <button
            onClick={() => setShowCreate(true)}
            className="w-full flex items-center justify-center gap-2 rounded-2xl border border-dashed border-purple-300 bg-purple-50/60 py-2 text-xs font-semibold text-purple-700 hover:bg-purple-100 active:bg-purple-200 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Create Tournament</span>
          </button>
        </div>
      );
    }

    return (
      <div className="px-4 pt-3 pb-2 bg-white">
        <div className="rounded-2xl border border-purple-200 bg-purple-50/60 p-3 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-slate-900">
              New Tournament
            </p>
            <button
              type="button"
              onClick={() => {
                resetForm();
                setShowCreate(false);
              }}
              className="text-[11px] text-slate-500 hover:text-slate-800"
            >
              Cancel
            </button>
          </div>

          <form className="space-y-3" onSubmit={handleCreateTournament}>
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-700">
                Name *
              </label>
              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-purple-500"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Summer Cup 2025"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[11px] font-medium text-slate-700">
                  Season
                </label>
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-purple-500"
                  value={season}
                  onChange={(e) => setSeason(e.target.value)}
                  placeholder="2024/25"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-slate-700">
                  Country
                </label>
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-purple-500"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder="India"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[11px] font-medium text-slate-700">
                  Starts
                </label>
                <input
                  type="date"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-purple-500"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-medium text-slate-700">
                  Ends
                </label>
                <input
                  type="date"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-purple-500"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-700">
                Status
              </label>
              <select
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-purple-500"
                value={status}
                onChange={(e) =>
                  setStatus(e.target.value as TournamentStatus)
                }
              >
                <option value="UPCOMING">Upcoming</option>
                <option value="LIVE">Live</option>
                <option value="COMPLETED">Completed</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            </div>

            {error && (
              <p className="text-[11px] text-red-600 bg-red-50 border border-red-100 rounded-xl px-3 py-1.5">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={creating}
              className="w-full mt-1 rounded-2xl bg-purple-600 hover:bg-purple-500 active:bg-purple-700 px-3 py-1.5 text-xs font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {creating && <Loader2 className="w-3 h-3 animate-spin" />}
              <span>Create</span>
            </button>
          </form>
        </div>
      </div>
    );
  };

  const renderList = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center py-10">
          <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
        </div>
      );
    }

    if (error && !showCreate) {
      return (
        <div className="px-4 py-6 text-xs text-red-600">{error}</div>
      );
    }

    if (!items.length) {
      return (
        <div className="px-4 py-6 text-xs text-slate-500">
          No tournaments yet. Create your first tournament to get started.
        </div>
      );
    }

    return (
      <div className="px-4 pb-4 pt-2 space-y-2">
        {items.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => onTournamentClick(t)}
            className="w-full text-left rounded-2xl bg-white shadow-[0_1px_3px_rgba(15,23,42,0.08)] px-3 py-2.5 flex items-center justify-between active:scale-[0.99] transition-transform"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-purple-100 flex items-center justify-center">
                <Trophy className="w-4 h-4 text-purple-700" />
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-900">
                  {t.name}
                </p>
                <p className="text-[11px] text-slate-500 flex items-center gap-1">
                  {t.season && (
                    <>
                      <Calendar className="w-3 h-3" />
                      <span>{t.season}</span>
                    </>
                  )}
                  {t.country && (
                    <>
                      <span className="mx-1">•</span>
                      <Flag className="w-3 h-3" />
                      <span>{t.country}</span>
                    </>
                  )}
                </p>
              </div>
            </div>
            <div className="text-right text-[11px] text-slate-500">
              <span>{t.status || "UPCOMING"}</span>
              {t.startDate && (
                <div className="mt-0.5">
                  {new Date(t.startDate).toLocaleDateString()}
                </div>
              )}
            </div>
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {renderHeader()}
      {renderCreateForm()}
      {renderList()}
    </div>
  );
};

export default TournamentListScreen;
