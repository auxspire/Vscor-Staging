import React, { useState, useEffect } from 'react';
import { Search, Filter, Calendar, MapPin } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { supabase } from '../lib/supabaseClient';
import type { TeamClickPayload, TournamentClickPayload } from '../lib/matches';

// ---- Types ----

type LiveMatch = {
  id: string | number;
  teamA: string;
  teamB: string;
  scoreA: number;
  scoreB: number;
  tournament: string;
  time: string;
  status: 'live' | 'finished' | 'upcoming' | 'other';
  venue: string;
  spectators: number | null;
  recentEvents: {
    minute: number;
    type: string;
    player: string | null;
    team: string | null;
  }[];
};

type LiveMatchesScreenProps = {
  onMatchClick: (match: LiveMatch) => void;
  onPlayerClick?: (player: any) => void; // reserved for later use
  onTeamClick?: (team: TeamClickPayload) => void;
  onTournamentClick?: (tournament: TournamentClickPayload) => void;
};

const LiveMatchesScreen: React.FC<LiveMatchesScreenProps> = ({
  onMatchClick,
  onPlayerClick,
  onTeamClick,
  onTournamentClick,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [matches, setMatches] = useState<LiveMatch[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // ---- Helpers to map DB rows → UI shape ----

  const mapMatchRow = (row: any): LiveMatch => {
    const teamA =
      row.teamA ??
      row.team_a_name ??
      row.team_a ??
      row.home_team ??
      row.team1 ??
      'Team A';

    const teamB =
      row.teamB ??
      row.team_b_name ??
      row.team_b ??
      row.away_team ??
      row.team2 ??
      'Team B';

    const scoreA =
      row.scoreA ??
      row.score_a ??
      row.home_score ??
      0;

    const scoreB =
      row.scoreB ??
      row.score_b ??
      row.away_score ??
      0;

    const rawStatus: string = (row.status || '').toLowerCase();
    let status: LiveMatch['status'] = 'other';

    if (rawStatus === 'live' || row.is_live) status = 'live';
    else if (rawStatus === 'finished' || rawStatus === 'ft' || row.is_finished) status = 'finished';
    else if (rawStatus === 'upcoming' || rawStatus === 'scheduled') status = 'upcoming';

    const tournament =
      row.tournament ??
      row.competition_name ??
      'Tournament';

    const venue =
      row.venue ??
      row.stadium ??
      'Venue';

    const spectators: number | null =
      row.spectators ??
      row.attendance ??
      null;

    // time label: fallback to "Live" / "Final" if nothing else
    const timeLabel: string =
      row.time_label ??
      row.time ??
      (status === 'live' ? 'Live' : status === 'finished' ? 'Final' : '');

    return {
      id: row.id,
      teamA: String(teamA),
      teamB: String(teamB),
      scoreA: scoreA ?? 0,
      scoreB: scoreB ?? 0,
      tournament: String(tournament),
      time: timeLabel,
      status,
      venue: String(venue),
      spectators,
      recentEvents: [],
    };
  };

  const mapEventRow = (row: any) => {
    let minute = 0;
    if (typeof row.minute === 'number') {
      minute = row.minute;
    } else if (typeof row.minute === 'string') {
      const parsed = parseInt(row.minute, 10);
      minute = Number.isNaN(parsed) ? 0 : parsed;
    } else if (typeof row.minute_mark === 'number') {
      minute = row.minute_mark;
    } else if (typeof row.time === 'string') {
      // e.g. "65:12"
      const m = parseInt(row.time.split(':')[0], 10);
      minute = Number.isNaN(m) ? 0 : m;
    }

    const type: string = row.event_type || row.type || 'event';
    const player: string | null =
      row.player_name ??
      row.player ??
      null;
    const team: string | null =
      row.team_name ??
      row.team ??
      row.team_side_name ??
      null;

    return {
      minute,
      type,
      player,
      team,
    };
  };

  // ---- Load matches + recent events from Supabase ----

  const loadMatches = async () => {
    try {
      setLoading(true);
      setError(null);

      // 1) Load matches
      const { data: matchRows, error: matchError } = await supabase
        .from('matches')
        .select('*')
        .order('created_at', { ascending: false }); // change column if needed

      if (matchError) {
        console.error('[LiveMatchesScreen] matches error', matchError);
        setError(matchError.message || 'Could not load matches');
        setMatches([]);
        return;
      }

      const mappedMatches: LiveMatch[] = (matchRows ?? []).map(mapMatchRow);

      // 2) Load recent events for all these matches
      const matchIds = (matchRows ?? []).map((r: any) => r.id);
      if (matchIds.length > 0) {
        const { data: eventRows, error: eventsError } = await supabase
          .from('match_events')
          .select('*')
          .in('match_id', matchIds)
          .order('minute', { ascending: false });

        if (eventsError) {
          console.warn('[LiveMatchesScreen] match_events error (non-fatal)', eventsError);
        } else if (eventRows) {
          const eventsByMatchId: Record<string | number, ReturnType<typeof mapEventRow>[]> = {};
          for (const row of eventRows) {
            const ev = mapEventRow(row);
            const key: string | number = row.match_id;
            if (!eventsByMatchId[key]) eventsByMatchId[key] = [];
            eventsByMatchId[key].push(ev);
          }

          // attach top 2 events as "recentEvents"
          for (let i = 0; i < mappedMatches.length; i++) {
            const m = mappedMatches[i];
            const evs = eventsByMatchId[m.id] || [];
            mappedMatches[i] = {
              ...m,
              recentEvents: evs.slice(0, 2),
            };
          }
        }
      }

      setMatches(mappedMatches);
    } catch (e: any) {
      console.error('[LiveMatchesScreen] unexpected error', e);
      setError(e?.message || 'Could not load matches');
      setMatches([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMatches();
  }, []);

  // Filter matches based on search query
  const filteredMatches = matches.filter((match) =>
    match.teamA.toLowerCase().includes(searchQuery.toLowerCase()) ||
    match.teamB.toLowerCase().includes(searchQuery.toLowerCase()) ||
    match.tournament.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleTeamNameClick = (
    e: React.MouseEvent<HTMLButtonElement>,
    teamName: string
  ) => {
    e.stopPropagation();
    onTeamClick?.({
      id: teamName === 'Manchester United' ? 1 : 2,
      name: teamName,
      matches: 28,
      wins: 18,
      goals: 58,
    });
  };

  const handleTournamentNameClick = (
    e: React.MouseEvent<HTMLButtonElement>,
    tournamentName: string
  ) => {
    e.stopPropagation();
    onTournamentClick?.({
      id: 1,
      name: tournamentName,
      teams: 20,
      matches: 380,
    });
  };

  const getMatchStatusBadge = (match: LiveMatch) => {
    if (match.status === 'live') {
      return (
        <Badge className="bg-red-500 text-white animate-pulse">
          {match.time || 'Live'}
        </Badge>
      );
    } else {
      return (
        <Badge variant="outline" className="bg-gray-100 text-gray-600">
          {match.time || 'Final'}
        </Badge>
      );
    }
  };

  return (
    <div className="p-6 space-y-6 pb-24">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-medium mb-2">Live Matches</h1>
        <p className="text-purple-600 text-lg">Stay Updated with Real-time Scores</p>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          placeholder="Search teams, tournaments..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-12 pr-4 py-3 bg-purple-50 border-none rounded-full"
        />
      </div>

      {/* Filter Button */}
      <Button variant="outline" className="rounded-full px-6">
        <Filter className="w-4 h-4 mr-2" />
        Filter Matches
      </Button>

      {/* Error state */}
      {error && (
        <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
          {error}
        </div>
      )}

      {/* Loading state */}
      {loading && matches.length === 0 && (
        <div className="text-center text-sm text-gray-500 py-6">
          Loading matches…
        </div>
      )}

      {/* Live Matches List */}
      <div className="space-y-4">
        {filteredMatches.map((match) => (
          <div
            key={match.id}
            onClick={() => onMatchClick(match)}
            className="bg-purple-100 rounded-2xl p-6 cursor-pointer hover:bg-purple-150 transition-colors border border-purple-200 hover:border-purple-300"
          >
            {/* Match Status and Tournament */}
            <div className="flex justify-between items-center mb-4">
              <button
                onClick={(e) => handleTournamentNameClick(e, match.tournament)}
                className="text-sm text-purple-600 hover:text-purple-800 hover:underline font-medium"
              >
                {match.tournament}
              </button>
              {getMatchStatusBadge(match)}
            </div>

            {/* Match Venue and Spectators */}
            <div className="flex items-center gap-4 text-xs text-gray-600 mb-4">
              <div className="flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                <span>{match.venue}</span>
              </div>
              {match.spectators !== null && (
                <div className="text-xs text-gray-500">
                  {match.spectators.toLocaleString()} spectators
                </div>
              )}
            </div>

            {/* Team Names and Score */}
            <div className="flex items-center justify-between gap-4">
              {/* Team A */}
              <div className="flex flex-col items-center gap-2 flex-1">
                <div className="w-12 h-12 bg-purple-200 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="font-medium text-purple-600">
                    {match.teamA
                      .split(' ')
                      .map((word: string) => word[0])
                      .join('')
                      .slice(0, 2)}
                  </span>
                </div>
                <button
                  onClick={(e) => handleTeamNameClick(e, match.teamA)}
                  className="text-center hover:text-purple-600 hover:underline transition-colors text-sm"
                >
                  <p className="line-clamp-2">{match.teamA}</p>
                </button>
              </div>

              {/* Score */}
              <div className="flex-shrink-0 px-4">
                <div className="text-2xl">
                  {match.scoreA} - {match.scoreB}
                </div>
              </div>

              {/* Team B */}
              <div className="flex flex-col items-center gap-2 flex-1">
                <div className="w-12 h-12 bg-purple-200 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="font-medium text-purple-600">
                    {match.teamB
                      .split(' ')
                      .map((word: string) => word[0])
                      .join('')
                      .slice(0, 2)}
                  </span>
                </div>
                <button
                  onClick={(e) => handleTeamNameClick(e, match.teamB)}
                  className="text-center hover:text-purple-600 hover:underline transition-colors text-sm"
                >
                  <p className="line-clamp-2">{match.teamB}</p>
                </button>
              </div>
            </div>

            {/* Recent Events Preview */}
            {match.recentEvents && match.recentEvents.length > 0 && (
              <div className="mt-4 pt-4 border-t border-purple-200">
                <p className="text-xs text-gray-600 mb-2">Recent Events:</p>
                <div className="flex gap-2 flex-wrap">
                  {match.recentEvents.map((event, index) => (
                    <div key={index} className="text-xs bg-white rounded-lg px-2 py-1">
                      <span className="font-medium">{event.minute}'</span>{' '}
                      {event.type} {event.player ? `- ${event.player}` : ''}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* No matches found */}
      {!loading && filteredMatches.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <h3 className="text-lg font-medium text-gray-600 mb-2">No matches found</h3>
          <p className="text-gray-500">Try adjusting your search or check back later</p>
        </div>
      )}
    </div>
  );
};

export default LiveMatchesScreen;
