import React from "react";
import { Plus, Star, Users, User } from "lucide-react";

type MatchSummary = {
  id: number;
  teamA: string;
  teamB: string;
  scoreA: number;
  scoreB: number;
  tournament: string;
  status: string;
};

type ScoringTabProps = {
  onNewMatch: () => void;
  onAddTeam: () => void;
  onAddPlayer: () => void;
  onAddTournament: () => void;
  onMatchClick: (match: MatchSummary) => void;
};

const ScoringTab: React.FC<ScoringTabProps> = ({
  onNewMatch,
  onAddTeam,
  onAddPlayer,
  onAddTournament,
  onMatchClick,
}) => {
  const recentMatches: MatchSummary[] = [
    {
      id: 1,
      teamA: "Team A",
      teamB: "Team B",
      scoreA: 2,
      scoreB: 1,
      tournament: "Tournament Name",
      status: "Final",
    },
    {
      id: 2,
      teamA: "Team A",
      teamB: "Team B",
      scoreA: 2,
      scoreB: 1,
      tournament: "Tournament Name",
      status: "Final",
    },
  ];

  const quickActions = [
    {
      title: "New Match",
      icon: Plus,
      action: onNewMatch,
      bgColor: "bg-purple-200",
    },
    {
      title: "Add Tournament",
      icon: Star,
      action: onAddTournament,
      bgColor: "bg-purple-200",
    },
    {
      title: "Add Team",
      icon: Users,
      action: onAddTeam,
      bgColor: "bg-purple-200",
    },
    {
      title: "Add Player",
      icon: User,
      action: onAddPlayer,
      bgColor: "bg-purple-200",
    },
  ] as const;

  return (
    <div className="p-6 space-y-6 pb-24">
      <div>
        <h1 className="text-2xl font-medium mb-2">Scoring</h1>
        <p className="text-purple-600 text-lg">Quick Actions</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {quickActions.map((action, index) => (
          <button
            key={index}
            type="button"
            onClick={action.action}
            className="bg-purple-100 rounded-2xl p-6 cursor-pointer hover:bg-purple-150 transition-colors w-full"
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <div
                className={`w-16 h-16 ${action.bgColor} rounded-full flex items-center justify-center`}
              >
                <action.icon className="w-8 h-8 text-purple-600" />
              </div>
              <p className="font-medium text-purple-900">{action.title}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="flex justify-between items-center">
        <h2 className="text-lg font-medium">Recent Matches</h2>
        <button type="button" className="text-purple-600">
          View All
        </button>
      </div>

      <div className="space-y-3">
        {recentMatches.map((match) => (
          <button
            key={match.id}
            type="button"
            onClick={() => onMatchClick(match)}
            className="bg-white border border-gray-200 rounded-2xl p-4 cursor-pointer hover:bg-gray-50 transition-colors w-full text-left"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-medium">A</span>
                </div>
                <div>
                  <p className="font-medium">
                    {match.teamA} vs {match.teamB}
                  </p>
                  <p className="text-sm text-gray-600">{match.tournament}</p>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xl font-medium">
                  {match.scoreA} - {match.scoreB}
                </div>
                <div className="bg-purple-100 text-purple-600 px-3 py-1 rounded-lg text-sm">
                  {match.status}
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ScoringTab;
