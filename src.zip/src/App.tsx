// src/App.tsx
import React, { useState, useEffect, FormEvent } from "react";
import ScoringDashboard, {
  type RecentMatch as DashboardRecentMatch,
} from "./components/ScoringDashboard";
import NewMatch, { type MatchDetails } from "./components/NewMatch";
import SelectSquad from "./components/SelectSquad";
import { loadRecentMatches,createMatchForAdHocGame } from "./lib/matches";

// 🔴 NEW: tournaments module
import TournamentListScreen, {
  type TournamentSummary as TournamentListSummary,
} from "./components/TournamentListScreen";
import TournamentProfileContainer from "./components/TournamentProfileContainer";

// Which main screen we’re on (after login)
type Screen =
  | "dashboard"
  | "newMatch"
  | "selectSquad"
  | "tournaments"
  | "tournamentProfile";

// 🔐 Preset demo credentials
const PRESET_USERNAME = "gummy";
const PRESET_PASSWORD = "gummy";

const App: React.FC = () => {
  const [isAuthed, setIsAuthed] = useState(false);
  const [activeScreen, setActiveScreen] = useState<Screen>("dashboard");

  const [loginUser, setLoginUser] = useState("");
  const [loginPass, setLoginPass] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);

  const [recentMatches, setRecentMatches] = useState<DashboardRecentMatch[]>(
    []
  );

  const [matchDraft, setMatchDraft] = useState<MatchDetails | null>(null);

  // 🔴 for tournament profile
  const [selectedTournament, setSelectedTournament] =
    useState<TournamentListSummary | null>(null);

  // ---- Restore login from localStorage ----
  useEffect(() => {
    try {
      const stored = window.localStorage.getItem("vscor_login_ok");
      if (stored === "1") {
        setIsAuthed(true);
        setActiveScreen("dashboard");
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  // ---- Load recent matches once you are authed ----
  useEffect(() => {
    if (!isAuthed) return;

    (async () => {
      const rows = await loadRecentMatches(5);
      const mapped: DashboardRecentMatch[] = rows.map((r) => ({
        id: r.id,
        teamA: r.teamA,
        teamB: r.teamB,
        scoreA: r.scoreA,
        scoreB: r.scoreB,
        tournamentName: r.tournamentName ?? undefined,
        status: r.status ?? undefined,
      }));
      setRecentMatches(mapped);
    })();
  }, [isAuthed]);

  // ---- Login handler ----
  const handleLoginSubmit = (e: FormEvent) => {
    e.preventDefault();
    const u = loginUser.trim();
    const p = loginPass;

    if (u === PRESET_USERNAME && p === PRESET_PASSWORD) {
      setIsAuthed(true);
      setLoginError(null);
      try {
        window.localStorage.setItem("vscor_login_ok", "1");
      } catch {
        // ignore storage errors
      }
      setActiveScreen("dashboard");
    } else {
      setLoginError("Invalid username or password");
    }
  };

  const handleLogout = () => {
    setIsAuthed(false);
    setActiveScreen("dashboard");
    setLoginUser("");
    setLoginPass("");
    try {
      window.localStorage.removeItem("vscor_login_ok");
    } catch {
      // ignore storage errors
    }
  };

  // =========================
  //  Unauthed: Login Screen
  // =========================
  if (!isAuthed) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 px-4">
        <div className="w-full max-w-sm bg-white rounded-2xl shadow-md p-6 space-y-5">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900">
              VScor Login
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Demo access with preset credentials.
            </p>
          </div>

          {loginError && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              {loginError}
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700">
                Username
              </label>
              <input
                type="text"
                value={loginUser}
                onChange={(e) => setLoginUser(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="gummy"
                autoComplete="username"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700">
                Password
              </label>
              <input
                type="password"
                value={loginPass}
                onChange={(e) => setLoginPass(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="gummy"
                autoComplete="current-password"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-purple-600 text-white text-sm font-medium py-2.5 hover:bg-purple-700 transition-colors"
            >
              Sign in
            </button>
          </form>

          <div className="text-xs text-slate-500 pt-2 border-t border-slate-100">
            <p>Preset demo credentials:</p>
            <p>
              <span className="font-mono">username:</span>{" "}
              <span className="font-mono">gummy</span>
            </p>
            <p>
              <span className="font-mono">password:</span>{" "}
              <span className="font-mono">gummy</span>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // =========================
  //  Authed: Main App
  // =========================
  const renderBody = () => {
    // DASHBOARD
    if (activeScreen === "dashboard") {
      return (
        <ScoringDashboard
          recentMatches={recentMatches}
          onNewMatch={() => setActiveScreen("newMatch")}
          // opens tournaments module
          onAddTournament={() => {
            setActiveScreen("tournaments");
          }}
          onAddTeam={() => {
            // TODO: wire team creation screen
            alert("Team creation screen coming soon.");
          }}
          onAddPlayer={() => {
            // TODO: wire player creation screen
            alert("Player creation screen coming soon.");
          }}
        />
      );
    }

    // NEW MATCH
   if (activeScreen === "newMatch") {
  return (
    <NewMatch
      onBack={() => setActiveScreen("dashboard")}
      onSelectSquad={async (details) => {
        try {
          // 1) Create a row in `matches`
          const { id } = await createMatchForAdHocGame({
            team1: details.team1,
            team2: details.team2,
            playersPerTeam: details.playersPerTeam,
          });

          // 2) Store draft with attached match.id for SelectSquad
          setMatchDraft({
            ...(details as any), // avoid TS whining about extra `id`
            id,
          });

          // 3) Go to SelectSquad
          setActiveScreen("selectSquad");
        } catch (e) {
          console.error("[App] Failed to create match", e);
          alert("Failed to create match in database. Please try again.");
        }
      }}
      registeredTeams={[]}
      onAddTeam={() => {
        alert("Team creation flow coming soon.");
      }}
      playerDatabase={[]}
    />
  );
}


    // SELECT SQUAD
    if (activeScreen === "selectSquad" && matchDraft) {
      return (
        <SelectSquad
          match={{
            ...matchDraft,
            playersPerTeam:
              parseInt(String(matchDraft.playersPerTeam), 10) || 11,
          }}
          onBack={() => setActiveScreen("newMatch")}
          onStartMatch={(matchWithSquads) => {
            console.log("[VScor] Match ready to start:", matchWithSquads);
            alert("Match squads saved. Live scoring wiring is next.");
            setActiveScreen("dashboard");
          }}
          registeredTeams={[]}
          playerDatabase={[]}
        />
      );
    }

    // TOURNAMENT LIST
    if (activeScreen === "tournaments") {
      return (
        <TournamentListScreen
          tournaments={[]} // component loads from Supabase internally
          onBack={() => setActiveScreen("dashboard")}
          onTournamentClick={(t) => {
            setSelectedTournament(t);
            setMatchDraft(null); // reset any previous draft
            setActiveScreen("tournamentProfile");
          }}
        />
      );
    }

    // TOURNAMENT PROFILE
    if (activeScreen === "tournamentProfile") {
      if (!selectedTournament) {
        return (
          <div className="p-6">
            <p className="text-sm text-slate-600">
              No tournament selected. Returning to list…
            </p>
            <button
              onClick={() => setActiveScreen("tournaments")}
              className="mt-3 inline-flex items-center rounded-lg bg-purple-600 text-white text-sm font-medium px-4 py-2"
            >
              Back to Tournaments
            </button>
          </div>
        );
      }

      return (
        <TournamentProfileContainer
          tournamentId={selectedTournament.id}
          onBack={() => setActiveScreen("tournaments")}
          onMatchClick={(fixture) => {
            // 🔥 Build a matchDraft from the clicked fixture and jump to SelectSquad

            setMatchDraft({
              team1: fixture.teamA || "",
              team2: fixture.teamB || "",
              matchFormat: "single",
              // you can tweak this default duration if needed
              duration: "90",
              venue: fixture.venue || "",
              playersPerTeam: "11",
              startTime: new Date(),
              scoreA: 0,
              scoreB: 0,
              events: [],
              // link back to fixture/tournament if your MatchDetails supports it
              // @ts-ignore – depends on your MatchDetails type
              fixtureId: fixture.id,
              // @ts-ignore – depends on your MatchDetails type
              tournamentId: selectedTournament.id,
            } as MatchDetails);

            // Option A: go straight to squad selection
            setActiveScreen("selectSquad");

            // Option B (if you prefer to review details first):
            // setActiveScreen("newMatch");
          }}
        />
      );
    }

    // Fallback (should not really happen)
    return (
      <div className="p-6">
        <p className="text-sm text-slate-600">
          Something went wrong with navigation. Returning to dashboard…
        </p>
        <button
          onClick={() => setActiveScreen("dashboard")}
          className="mt-3 inline-flex items-center rounded-lg bg-purple-600 text-white text-sm font-medium px-4 py-2"
        >
          Go to Dashboard
        </button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <header className="w-full border-b border-slate-200 bg-white">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold text-slate-900">VScor</h1>
            <p className="text-xs text-slate-500">
              Tournament scoring &amp; match management
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveScreen("dashboard")}
              className="text-xs text-slate-600 hover:text-slate-900"
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveScreen("tournaments")}
              className="text-xs text-slate-600 hover:text-slate-900"
            >
              Tournaments
            </button>
            <button
              onClick={handleLogout}
              className="text-xs text-slate-500 hover:text-red-600"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full">{renderBody()}</main>
    </div>
  );
};

export default App;
