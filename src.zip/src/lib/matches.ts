import { supabase } from "./supabaseClient";

// ---------------------------
// Match Status
// ---------------------------
export type MatchStatus =
  | "scheduled"
  | "live"
  | "finished"
  | "abandoned"
  | "postponed";

// ---------------------------
// Event Types
// ---------------------------
export type MatchEventType =
  | "goal"
  | "assist"
  | "yellow_card"
  | "red_card"
  | "foul"
  | "offside"
  | "corner"
  | "kickoff"
  | "substitution"
  | "shot_on_goal"
  | "off_target"
  | "other";

// ---------------------------
// Match Event (DB + UI)
// ---------------------------
export interface MatchEvent {
  id: string | number;
  matchId: string | number;

  type: MatchEventType;
  minute: number;

  teamName: string | null;
  playerName?: string | null;
  assistName?: string | null;

  playerOutName?: string | null; // substitutions
  playerInName?: string | null;

  raw?: any; // raw DB row if needed
}

// ---------------------------
// Main Match Model
// ---------------------------
export interface Match {
  id: string | number;

  teamA: string;
  teamB: string;

  scoreA: number;
  scoreB: number;

  tournament: string;
  venue: string;

  status: MatchStatus;
  time: string; // "Live: 67’", "Final", or "17:00 Kickoff"

  spectators?: number | null;

  startedAt?: string | null;
  endedAt?: string | null;
  durationMinutes?: number | null;

  events?: MatchEvent[]; // optional — populate when loading events
}
export type NewMatchInput = {
  team1: string;
  team2: string;
  playersPerTeam?: number | string;
  // You can extend this later with venue, tournamentId, kickoffAt, etc.
};


// ---------------------------
// Click Payload Types (UI)
// ---------------------------
export interface TeamClickPayload {
  id: number;
  name: string;
  matches: number;
  wins: number;
  goals: number;
}

export interface TournamentClickPayload {
  id: number;
  name: string;
  teams: number;
  matches: number;
}

type ApplyResultInput = {
  tournamentId: string;
  homeTeamId: string;
  awayTeamId: string;
  homeScore: number;
  awayScore: number;
};

// DB row helpers
type MatchDbRow = {
  id: string;
  tournament_id: string | null;
  tournament_fixture_id: string | null;
  home_team_id: string | null;
  away_team_id: string | null;
  home_score: number | null;
  away_score: number | null;
  status: string | null;
  started_at: string | null;
  ended_at: string | null;
};

type TournamentFixtureRow = {
  id: string;
  tournament_id: string | null;
  home_team_id: string | null;
  away_team_id: string | null;
  kickoff_at: string | null;
  status: string | null;
};

// ---------------------------
// Finalize Match in DB
// ---------------------------

/**
 * Persist final match result to Supabase.
 * - Updates scores
 * - Marks status as "finished"
 * - Sets ended_at (and optionally duration_seconds if present)
 */
export type FinalizeMatchInput = {
  matchId: string | number;
  homeScore: number;
  awayScore: number;
  durationSeconds?: number;
};

/**
 * Persist final match result to Supabase.
 * - Updates scores in matches
 * - Marks status as "finished"
 * - Sets ended_at (and optionally duration_seconds if present)
 * - If the match is linked to a tournament fixture + teams,
 *   it also updates:
 *   - tournament_fixtures (home/away score + status)
 *   - tournament_standings (W/D/L, GF/GA, points, last5)
 */
export async function finalizeMatchInDb(
  input: FinalizeMatchInput
): Promise<void> {
  const { matchId, homeScore, awayScore, durationSeconds } = input;

  // 1) Update the matches row itself
  const updatePayload: Record<string, any> = {
    home_score: homeScore,
    away_score: awayScore,
    status: "finished" as MatchStatus,
    ended_at: new Date().toISOString(),
  };

  if (typeof durationSeconds === "number") {
    // Only if you have this column
    updatePayload.duration_seconds = durationSeconds;
  }

  const { error: matchUpdateError } = await supabase
    .from("matches")
    .update(updatePayload)
    .eq("id", matchId);

  if (matchUpdateError) {
    console.error("[matches] finalizeMatchInDb error:", matchUpdateError);
    throw new Error(matchUpdateError.message);
  }

  // 2) Load match row to see if it is linked to a tournament fixture + teams
  const { data: matchRow, error: matchFetchError } = await supabase
    .from("matches")
    .select(
      `
        id,
        tournament_id,
        tournament_fixture_id,
        home_team_id,
        away_team_id
      `
    )
    .eq("id", matchId)
    .maybeSingle();

  if (matchFetchError) {
    console.error(
      "[matches] finalizeMatchInDb: failed to load match row:",
      matchFetchError
    );
    // Don’t throw here – core match update already succeeded.
    return;
  }

  if (!matchRow) {
    console.warn(
      "[matches] finalizeMatchInDb: match row not found after update"
    );
    return;
  }

  const tournamentId: string | null = matchRow.tournament_id;
  const fixtureId: string | null = matchRow.tournament_fixture_id;
  const homeTeamId: string | null = matchRow.home_team_id;
  const awayTeamId: string | null = matchRow.away_team_id;

  // 3) If there is a linked tournament fixture, update it
  if (fixtureId) {
    const { error: fixtureError } = await supabase
      .from("tournament_fixtures")
      .update({
        home_score: homeScore,
        away_score: awayScore,
        status: "completed", // NOTE: your recalc uses "finished"; adjust later if needed
      })
      .eq("id", fixtureId);

    if (fixtureError) {
      console.error(
        "[matches] finalizeMatchInDb: update tournament_fixtures failed:",
        fixtureError
      );
      // Not fatal for match update
    }
  }

  // 4) If we have a tournament + both teams, apply result to standings
  if (tournamentId && homeTeamId && awayTeamId) {
    try {
      await applyResultToStandings({
        tournamentId,
        homeTeamId,
        awayTeamId,
        homeScore,
        awayScore,
      });
    } catch (e) {
      console.error(
        "[matches] finalizeMatchInDb: applyResultToStandings failed:",
        e
      );
    }
  }
}

// ----------------------------------------------------------------------
// NEW: ensureMatchForFixture
// ----------------------------------------------------------------------

/**
 * Given a tournament_fixtures.id, ensure there is a linked row in `matches`.
 * - If a match already exists for that fixture, returns it.
 * - Otherwise creates a new `matches` row linked to that fixture and returns it.
 */
export async function ensureMatchForFixture(
  fixtureId: string | number
): Promise<MatchDbRow> {
  if (!fixtureId) {
    throw new Error("[matches] ensureMatchForFixture called without fixtureId");
  }

  const fixtureIdStr = String(fixtureId);

  // 1) Load the fixture
  const { data: fixture, error: fixtureError } = await supabase
    .from("tournament_fixtures")
    .select(
      `
        id,
        tournament_id,
        home_team_id,
        away_team_id,
        kickoff_at,
        status
      `
    )
    .eq("id", fixtureIdStr)
    .maybeSingle<TournamentFixtureRow>();

  if (fixtureError || !fixture) {
    console.error("[matches] ensureMatchForFixture fixture error:", fixtureError);
    throw new Error("Unable to load fixture for LiveScoring.");
  }

  // 2) Check if a match already exists for this fixture
  const { data: existingMatch, error: existingError } = await supabase
    .from("matches")
    .select(
      `
        id,
        tournament_id,
        tournament_fixture_id,
        home_team_id,
        away_team_id,
        home_score,
        away_score,
        status,
        started_at,
        ended_at
      `
    )
    .eq("tournament_fixture_id", fixture.id)
    .maybeSingle<MatchDbRow>();

  if (existingError && (existingError as any).code !== "PGRST116") {
    // PGRST116 = no rows found
    console.error(
      "[matches] ensureMatchForFixture existing match error:",
      existingError
    );
    throw new Error("Unable to look up existing match for fixture.");
  }

  if (existingMatch) {
    return existingMatch;
  }

  // 3) No match yet → create one
  const insertPayload = {
    tournament_id: fixture.tournament_id,
    tournament_fixture_id: fixture.id,
    home_team_id: fixture.home_team_id,
    away_team_id: fixture.away_team_id,
    home_score: 0,
    away_score: 0,
    status: "scheduled" as MatchStatus,
    started_at: null, // you can set kickoff_at if you want
    ended_at: null,
  };

  const { data: inserted, error: insertError } = await supabase
    .from("matches")
    .insert(insertPayload)
    .select(
      `
        id,
        tournament_id,
        tournament_fixture_id,
        home_team_id,
        away_team_id,
        home_score,
        away_score,
        status,
        started_at,
        ended_at
      `
    )
    .maybeSingle<MatchDbRow>();

  if (insertError || !inserted) {
    console.error(
      "[matches] ensureMatchForFixture insert error:",
      insertError
    );
    throw new Error("Unable to create match for fixture.");
  }

  return inserted;
}

// ----------------------------------------------------------------------
// Standings update for a single result (applyResultToStandings)
// ----------------------------------------------------------------------

async function applyResultToStandings(input: ApplyResultInput): Promise<void> {
  const { tournamentId, homeTeamId, awayTeamId, homeScore, awayScore } = input;

  // 1) Get points config from tournament_info (optional)
  let pointsForWin = 3;
  let pointsForDraw = 1;
  let pointsForLoss = 0;

  const { data: infoRow, error: infoError } = await supabase
    .from("tournament_info")
    .select("points_for_win, points_for_draw, points_for_loss")
    .eq("tournament_id", tournamentId)
    .maybeSingle();

  if (infoError) {
    console.warn(
      "[matches] applyResultToStandings: tournament_info error:",
      infoError
    );
  } else if (infoRow) {
    pointsForWin = infoRow.points_for_win ?? pointsForWin;
    pointsForDraw = infoRow.points_for_draw ?? pointsForDraw;
    pointsForLoss = infoRow.points_for_loss ?? pointsForLoss;
  }

  // 2) Load existing standings rows for these two teams
  const { data: existingRows, error: standingsError } = await supabase
    .from("tournament_standings")
    .select(
      `
        id,
        team_id,
        played,
        won,
        drawn,
        lost,
        goals_for,
        goals_against,
        goal_diff,
        points,
        last5,
        group_name
      `
    )
    .eq("tournament_id", tournamentId)
    .in("team_id", [homeTeamId, awayTeamId]);

  if (standingsError) {
    console.error(
      "[matches] applyResultToStandings: load error:",
      standingsError
    );
    throw new Error(standingsError.message);
  }

  const byTeamId = new Map<string, any>();
  (existingRows ?? []).forEach((row: any) => {
    byTeamId.set(row.team_id, row);
  });

  // Helper to compute result char + points
  const getResultChar = (gf: number, ga: number): "W" | "D" | "L" => {
    if (gf > ga) return "W";
    if (gf < ga) return "L";
    return "D";
  };

  const homeResult = getResultChar(homeScore, awayScore);
  const awayResult = getResultChar(awayScore, homeScore);

  const resultToPoints = (result: "W" | "D" | "L") => {
    switch (result) {
      case "W":
        return pointsForWin;
      case "D":
        return pointsForDraw;
      case "L":
      default:
        return pointsForLoss;
    }
  };

  // Helper to build new last5 string (prepend latest, keep max 5)
  const nextLast5 = (prev: string | null | undefined, res: "W" | "D" | "L") => {
    const base = (prev ?? "").toString().slice(0, 4); // keep at most 4 of old, we'll add new at front
    return (res + base).slice(0, 5);
  };

  const updates: any[] = [];
  const inserts: any[] = [];

  // 3) Prepare home row (update or insert)
  const homeExisting = byTeamId.get(homeTeamId);
  const homeBase = homeExisting || {
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    goals_for: 0,
    goals_against: 0,
    goal_diff: 0,
    points: 0,
    last5: null,
    group_name: null,
  };

  const homeResChar = homeResult;
  const homePointsDelta = resultToPoints(homeResChar);

  const homePlayed = (homeBase.played ?? 0) + 1;
  const homeWon = (homeBase.won ?? 0) + (homeResChar === "W" ? 1 : 0);
  const homeDrawn = (homeBase.drawn ?? 0) + (homeResChar === "D" ? 1 : 0);
  const homeLost = (homeBase.lost ?? 0) + (homeResChar === "L" ? 1 : 0);
  const homeGF = (homeBase.goals_for ?? 0) + homeScore;
  const homeGA = (homeBase.goals_against ?? 0) + awayScore;
  const homeGD = homeGF - homeGA;
  const homePoints = (homeBase.points ?? 0) + homePointsDelta;
  const homeLast5 = nextLast5(homeBase.last5, homeResChar);

  if (homeExisting) {
    updates.push({
      id: homeExisting.id,
      played: homePlayed,
      won: homeWon,
      drawn: homeDrawn,
      lost: homeLost,
      goals_for: homeGF,
      goals_against: homeGA,
      goal_diff: homeGD,
      points: homePoints,
      last5: homeLast5,
    });
  } else {
    inserts.push({
      tournament_id: tournamentId,
      team_id: homeTeamId,
      group_name: null,
      position: null, // you can later recalc proper positions
      played: homePlayed,
      won: homeWon,
      drawn: homeDrawn,
      lost: homeLost,
      goals_for: homeGF,
      goals_against: homeGA,
      goal_diff: homeGD,
      points: homePoints,
      last5: homeLast5,
    });
  }

  // 4) Prepare away row (update or insert)
  const awayExisting = byTeamId.get(awayTeamId);
  const awayBase = awayExisting || {
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    goals_for: 0,
    goals_against: 0,
    points: 0,
    goal_diff: 0,
    last5: null,
    group_name: null,
  };

  const awayResChar = awayResult;
  const awayPointsDelta = resultToPoints(awayResChar);

  const awayPlayed = (awayBase.played ?? 0) + 1;
  const awayWon = (awayBase.won ?? 0) + (awayResChar === "W" ? 1 : 0);
  const awayDrawn = (awayBase.drawn ?? 0) + (awayResChar === "D" ? 1 : 0);
  const awayLost = (awayBase.lost ?? 0) + (awayResChar === "L" ? 1 : 0);
  const awayGF = (awayBase.goals_for ?? 0) + awayScore;
  const awayGA = (awayBase.goals_against ?? 0) + homeScore;
  const awayGD = awayGF - awayGA;
  const awayPoints = (awayBase.points ?? 0) + awayPointsDelta;
  const awayLast5 = nextLast5(awayBase.last5, awayResChar);

  if (awayExisting) {
    updates.push({
      id: awayExisting.id,
      played: awayPlayed,
      won: awayWon,
      drawn: awayDrawn,
      lost: awayLost,
      goals_for: awayGF,
      goals_against: awayGA,
      goal_diff: awayGD,
      points: awayPoints,
      last5: awayLast5,
    });
  } else {
    inserts.push({
      tournament_id: tournamentId,
      team_id: awayTeamId,
      group_name: null,
      position: null,
      played: awayPlayed,
      won: awayWon,
      drawn: awayDrawn,
      lost: awayLost,
      goals_for: awayGF,
      goals_against: awayGA,
      goal_diff: awayGD,
      points: awayPoints,
      last5: awayLast5,
    });
  }

  // 5) Persist updates
  if (updates.length > 0) {
    const { error: updateError } = await supabase
      .from("tournament_standings")
      .upsert(updates, { onConflict: "id" });

    if (updateError) {
      console.error(
        "[matches] applyResultToStandings: update error:",
        updateError
      );
      throw new Error(updateError.message);
    }
  }

  if (inserts.length > 0) {
    const { error: insertError } = await supabase
      .from("tournament_standings")
      .insert(inserts);

    if (insertError) {
      console.error(
        "[matches] applyResultToStandings: insert error:",
        insertError
      );
      throw new Error(insertError.message);
    }
  }
}
export async function createMatchForAdHocGame(
  input: NewMatchInput
): Promise<{ id: string }> {
  const playersPerTeamNum =
    parseInt(String(input.playersPerTeam ?? 11), 10) || 11;

  const { data, error } = await supabase
    .from("matches")
    .insert({
      // If home_team_id / away_team_id are nullable, this is fine for now.
      home_score: 0,
      away_score: 0,
      status: "scheduled" as MatchStatus,
      // If you later add columns like players_per_team, venue, etc.:
      // players_per_team: playersPerTeamNum,
    })
    .select("id")
    .maybeSingle();

  if (error || !data) {
    console.error("[matches] createMatchForAdHocGame error:", error);
    throw (error ?? new Error("Failed to create match row"));
  }

  return { id: data.id as string };
}
// ---------------------------
// Standings full recalculation helpers
// ---------------------------

type ResultLetter = "W" | "D" | "L";
type TeamRole = "home" | "away";
type StandingAccumulator = {
  teamId: string;
  tournamentId: string;

  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  results: ResultLetter[]; // in chronological order
};

async function getPointsConfig(tournamentId: string): Promise<{
  win: number;
  draw: number;
  loss: number;
}> {
  const { data, error } = await supabase
    .from("tournament_info")
    .select(
      `
      points_for_win,
      points_for_draw,
      points_for_loss
    `
    )
    .eq("tournament_id", tournamentId)
    .maybeSingle();

  if (error) {
    console.warn(
      "[matches] getPointsConfig error, falling back to 3-1-0:",
      error
    );
  }

  return {
    win: data?.points_for_win ?? 3,
    draw: data?.points_for_draw ?? 1,
    loss: data?.points_for_loss ?? 0,
  };
}

/**
 * Recalculate standings for a whole tournament based on tournament_fixtures.
 * - Reads all finished fixtures for the tournament
 * - Aggregates per-team stats
 * - Wipes existing rows in tournament_standings for that tournament
 * - Inserts fresh, sorted rows with position + last5
 */
export async function recalculateStandingsForTournament(
  tournamentId: string
): Promise<void> {
  if (!tournamentId) return;

  const points = await getPointsConfig(tournamentId);

  // 1. Load all fixtures for this tournament
  const { data: fixtures, error: fixturesError } = await supabase
    .from("tournament_fixtures")
    .select(
      `
      id,
      tournament_id,
      status,
      home_team_id,
      away_team_id,
      home_score,
      away_score
    `
    )
    .eq("tournament_id", tournamentId);

  if (fixturesError) {
    console.error(
      "[matches] recalculateStandingsForTournament fixtures error:",
      fixturesError
    );
    throw new Error(fixturesError.message);
  }

  const finishedFixtures =
    fixtures?.filter(
      (f: any) =>
        f.status === "finished" &&
        typeof f.home_score === "number" &&
        typeof f.away_score === "number"
    ) ?? [];

  const acc = new Map<string, StandingAccumulator>();

  const getOrCreate = (teamId: string): StandingAccumulator => {
    let entry = acc.get(teamId);
    if (!entry) {
      entry = {
        teamId,
        tournamentId,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        goalsFor: 0,
        goalsAgainst: 0,
        results: [],
      };
      acc.set(teamId, entry);
    }
    return entry;
  };

  // 2. Aggregate stats
  for (const f of finishedFixtures) {
    const homeId = f.home_team_id as string | null;
    const awayId = f.away_team_id as string | null;
    const hs = f.home_score as number;
    const as = f.away_score as number;

    if (!homeId || !awayId) continue;

    const home = getOrCreate(homeId);
    const away = getOrCreate(awayId);

    home.played += 1;
    away.played += 1;

    home.goalsFor += hs;
    home.goalsAgainst += as;

    away.goalsFor += as;
    away.goalsAgainst += hs;

    let homeResult: ResultLetter;
    let awayResult: ResultLetter;

    if (hs > as) {
      home.won += 1;
      away.lost += 1;
      homeResult = "W";
      awayResult = "L";
    } else if (hs < as) {
      away.won += 1;
      home.lost += 1;
      homeResult = "L";
      awayResult = "W";
    } else {
      home.drawn += 1;
      away.drawn += 1;
      homeResult = "D";
      awayResult = "D";
    }

    home.results.push(homeResult);
    away.results.push(awayResult);
  }

  const rows = Array.from(acc.values()).map((row) => {
    const gd = row.goalsFor - row.goalsAgainst;
    const pointsTotal =
      row.won * points.win +
      row.drawn * points.draw +
      row.lost * points.loss;

    const last5 = row.results.slice(-5).join("");

    return {
      teamId: row.teamId,
      tournamentId: row.tournamentId,
      played: row.played,
      won: row.won,
      drawn: row.drawn,
      lost: row.lost,
      goalsFor: row.goalsFor,
      goalsAgainst: row.goalsAgainst,
      goalDiff: gd,
      points: pointsTotal,
      last5,
    };
  });

  // 3. Sort for positions: points desc, GD desc, GF desc
  rows.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    const gdA = a.goalDiff;
    const gdB = b.goalDiff;
    if (gdB !== gdA) return gdB - gdA;
    if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
    // stable-ish: arbitrary but deterministic
    return a.teamId.localeCompare(b.teamId);
  });

  // 4. Wipe existing standings for this tournament
  const { error: delError } = await supabase
    .from("tournament_standings")
    .delete()
    .eq("tournament_id", tournamentId);

  if (delError) {
    console.error(
      "[matches] recalculateStandingsForTournament delete error:",
      delError
    );
    throw new Error(delError.message);
  }

  if (rows.length === 0) {
    // No finished fixtures → empty table is fine.
    return;
  }

  // 5. Insert fresh rows
  const insertPayload = rows.map((row, index) => ({
    tournament_id: row.tournamentId,
    team_id: row.teamId,
    group_name: null,
    position: index + 1,
    played: row.played,
    won: row.won,
    drawn: row.drawn,
    lost: row.lost,
    goals_for: row.goalsFor,
    goals_against: row.goalsAgainst,
    goal_diff: row.goalDiff,
    points: row.points,
    last5: row.last5,
  }));

  const { error: insertError } = await supabase
    .from("tournament_standings")
    .insert(insertPayload);

  if (insertError) {
    console.error(
      "[matches] recalculateStandingsForTournament insert error:",
      insertError
    );
    throw new Error(insertError.message);
  }
}
export type SaveLineupsForMatchInput = {
  matchId: string | number;
  teamRole: TeamRole;
  players: Array<{
    id: string | number;
    name: string;
    jerseyNumber?: string | number;
    position?: string | null;
    // we ignore other fields from VscorPlayer for now
  }>;
};
export async function saveLineupsForMatch(
  input: SaveLineupsForMatchInput
): Promise<void> {
  const { matchId, teamRole, players } = input;

  if (!matchId) {
    console.warn("[matches] saveLineupsForMatch called without matchId");
    return;
  }

  const matchIdStr = String(matchId);
  const teamRoleStr: string = teamRole === "home" ? "home" : "away";

  // 1) Delete any existing rows for this match + team role
  const { error: delError } = await supabase
    .from("match_lineups")
    .delete()
    .eq("match_id", matchIdStr)
    .eq("team_role", teamRoleStr);

  if (delError) {
    console.error("[matches] saveLineupsForMatch delete error:", delError);
    throw new Error(delError.message);
  }

  if (!players || players.length === 0) {
    // No players to insert is valid – just means "clear this lineup"
    return;
  }

  // 2) Insert fresh rows
  const rowsToInsert = players.map((p, index) => ({
    match_id: matchIdStr,
    team_role: teamRoleStr, // "home" or "away"
    player_id: typeof p.id === "string" || typeof p.id === "number" ? p.id : null,
    player_name: p.name,
    jersey_number:
      p.jerseyNumber !== undefined && p.jerseyNumber !== null
        ? Number(p.jerseyNumber)
        : null,
    position: p.position ?? null,
    is_starting: true,
    sort_order: index + 1, // optional if you have this column
  }));

  const { error: insertError } = await supabase
    .from("match_lineups")
    .insert(rowsToInsert);

  if (insertError) {
    console.error("[matches] saveLineupsForMatch insert error:", insertError);
    throw new Error(insertError.message);
  }
}
/**
 * Convenience helper: given a fixture id, look up its tournament_id
 * and then recalculate standings for that tournament.
 */
export async function recalculateStandingsForFixture(
  fixtureId: string
): Promise<void> {
  if (!fixtureId) return;

  const { data, error } = await supabase
    .from("tournament_fixtures")
    .select("tournament_id")
    .eq("id", fixtureId)
    .maybeSingle();

  if (error) {
    console.error(
      "[matches] recalculateStandingsForFixture lookup error:",
      error
    );
    throw new Error(error.message);
  }

  const tournamentId = data?.tournament_id as string | undefined;
  if (!tournamentId) {
    console.warn(
      "[matches] recalculateStandingsForFixture: no tournament_id for fixture",
      fixtureId
    );
    return;
  }

  await recalculateStandingsForTournament(tournamentId);
}

// ----------------------------------------------------------------------
// Recent matches loader for Dashboard
// ----------------------------------------------------------------------

export type RecentMatchSummary = {
  id: string;
  teamA: string;
  teamB: string;
  scoreA: number;
  scoreB: number;
  tournamentName?: string | null;
  status?: string | null;
};

/**
 * Load recent matches for the Scoring dashboard.
 * - Pulls from `matches`
 * - Hydrates team + tournament names
 * - Returns data shaped for ScoringDashboard
 */
export async function loadRecentMatches(
  limit: number = 5
): Promise<RecentMatchSummary[]> {
  try {
    const { data: matchRows, error: matchError } = await supabase
      .from("matches")
      .select(
        `
        id,
        home_team_id,
        away_team_id,
        home_score,
        away_score,
        status,
        tournament_id,
        ended_at,
        created_at
      `
      )
      // NOTE: `nullsLast` is not supported in the TypeScript type for Supabase order()
      // so we just do a simple ordering that TS understands.
      .order("ended_at", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(limit);

    if (matchError) {
      console.error("[matches] loadRecentMatches: matches error:", matchError);
      return [];
    }

    const rows = matchRows ?? [];
    if (!rows.length) return [];

    const teamIds = new Set<string>();
    const tournamentIds = new Set<string>();

    rows.forEach((r: any) => {
      if (r.home_team_id) teamIds.add(r.home_team_id);
      if (r.away_team_id) teamIds.add(r.away_team_id);
      if (r.tournament_id) tournamentIds.add(r.tournament_id);
    });

    const teamMap = new Map<string, string>();
    const tournamentMap = new Map<string, string>();

    if (teamIds.size > 0) {
      const { data: teamRows, error: teamError } = await supabase
        .from("teams")
        .select("id, name")
        .in("id", Array.from(teamIds));

      if (teamError) {
        console.error(
          "[matches] loadRecentMatches: teams error:",
          teamError
        );
      } else {
        (teamRows ?? []).forEach((t: any) => {
          if (t.id) {
            teamMap.set(t.id, t.name || `Team ${String(t.id).slice(0, 4)}`);
          }
        });
      }
    }

    if (tournamentIds.size > 0) {
      const { data: tournamentRows, error: tournamentError } = await supabase
        .from("tournaments")
        .select("id, name")
        .in("id", Array.from(tournamentIds));

      if (tournamentError) {
        console.error(
          "[matches] loadRecentMatches: tournaments error:",
          tournamentError
        );
      } else {
        (tournamentRows ?? []).forEach((t: any) => {
          if (t.id) {
            tournamentMap.set(
              t.id,
              t.name || `Tournament ${String(t.id).slice(0, 4)}`
            );
          }
        });
      }
    }

    const mapTeamName = (id: string | null): string => {
      if (!id) return "Unknown Team";
      const found = teamMap.get(id);
      return found ?? `Team ${String(id).slice(0, 4)}`;
    };

    const mapTournamentName = (id: string | null): string | null => {
      if (!id) return null;
      const found = tournamentMap.get(id);
      return found ?? `Tournament ${String(id).slice(0, 4)}`;
    };

    return rows.map((r: any) => {
      const rawStatus = (r.status as string | null) ?? null;
      let statusLabel: string | null = null;

      if (rawStatus === "finished") statusLabel = "Final";
      else if (rawStatus === "live") statusLabel = "Live";
      else if (rawStatus === "scheduled") statusLabel = "Scheduled";
      else statusLabel = rawStatus;

      return {
        id: r.id,
        teamA: mapTeamName(r.home_team_id),
        teamB: mapTeamName(r.away_team_id),
        scoreA: typeof r.home_score === "number" ? r.home_score : 0,
        scoreB: typeof r.away_score === "number" ? r.away_score : 0,
        tournamentName: mapTournamentName(r.tournament_id),
        status: statusLabel,
      };
    });
  } catch (e) {
    console.error("[matches] loadRecentMatches: unexpected error:", e);
    return [];
  }
}
