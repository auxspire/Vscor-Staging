import { supabase } from "./supabaseClient"; // adjust path if needed

const STORAGE_KEY_PREFIX = "vscor-offline-events-";

export type QueuedEvent = {
  id: string; // local queue id
  matchId: string;
  payload: any; // this is your MatchEvent from LiveScoring
  createdAt: string; // ISO string
  synced?: boolean; // marks whether it was sent to Supabase
};

export type OfflineSyncResult = {
  syncedCount: number;
  stillPending: number;
};

export type OfflineSyncState = {
  total: number;
  unsynced: number;
};

/**
 * Internal helper to load events safely.
 */
function readLocalEvents(matchId: string): QueuedEvent[] {
  const key = STORAGE_KEY_PREFIX + matchId;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed;
  } catch (err) {
    console.error("[offlineEvents] Failed to read local events:", err);
    return [];
  }
}

/**
 * Internal helper to save events safely.
 */
function writeLocalEvents(matchId: string, events: QueuedEvent[]): void {
  const key = STORAGE_KEY_PREFIX + matchId;
  try {
    localStorage.setItem(key, JSON.stringify(events));
  } catch (err) {
    console.error("[offlineEvents] Failed to store local events:", err);
  }
}

/**
 * Get all locally stored events for a match (synced + unsynced).
 * LiveScoring currently maps e.payload, so we keep this shape.
 */
export function getLocalEventsForMatch(matchId: string): QueuedEvent[] {
  return readLocalEvents(matchId);
}

/**
 * Get a simple aggregate of offline state for UI badges.
 */
export function getOfflineSyncState(matchId: string): OfflineSyncState {
  const all = readLocalEvents(matchId);
  const unsynced = all.filter((e) => !e.synced).length;
  return {
    total: all.length,
    unsynced,
  };
}

/**
 * Append a new event to the local queue.
 */
export function queueLocalMatchEvent(matchId: string, payload: any): void {
  const current = readLocalEvents(matchId);

  const queued: QueuedEvent = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    matchId,
    payload,
    createdAt: new Date().toISOString(),
    synced: false,
  };

  const next = [...current, queued];
  writeLocalEvents(matchId, next);
}

/**
 * Try to push all UNSYNCED events for this match to Supabase.
 * - On success: mark them as synced in localStorage (we keep them for offline history).
 * - On failure: do NOT modify localStorage, so they can be retried later.
 *
 * Returns a small summary so the UI can show counts.
 */
export async function syncOfflineEventsForMatch(
  matchId: string
): Promise<OfflineSyncResult> {
  const all = readLocalEvents(matchId);
  const unsynced = all.filter((e) => !e.synced);

  if (!unsynced.length) {
    console.log("[offlineEvents] No unsynced events for match", matchId);
    return { syncedCount: 0, stillPending: 0 };
  }

  console.log(
    `[offlineEvents] Syncing ${unsynced.length} events for match`,
    matchId
  );

  // Transform to DB rows
  const rows = unsynced.map((e) => {
    const p = e.payload || {};
    // p.time like "3:21"
    let minute = 0;
    let second = 0;
    if (typeof p.time === "string") {
      const [m, s] = p.time.split(":");
      const mNum = parseInt(m, 10);
      const sNum = parseInt(s, 10);
      minute = Number.isNaN(mNum) ? 0 : mNum;
      second = Number.isNaN(sNum) ? 0 : sNum;
    }

    return {
      match_id: matchId,
      event_type: p.type ?? "unknown",
      team: p.team ?? null,
      team_name: p.teamName ?? null,
      player_id: p.player?.id ?? null,
      player_name: p.player?.name ?? null,
      player_number: p.player?.number?.toString?.() ?? null,
      minute,
      second,
      raw_payload: p,
    };
  });

  const { error } = await supabase.from("match_events").insert(rows);

  if (error) {
    console.error("[offlineEvents] Failed to sync events:", error);
    // do not mark as synced; they will be retried next time
    return { syncedCount: 0, stillPending: unsynced.length };
  }

  // Mark all those items as synced
  const syncedIds = new Set(unsynced.map((e) => e.id));
  const updated = all.map((e) =>
    syncedIds.has(e.id) ? { ...e, synced: true } : e
  );

  writeLocalEvents(matchId, updated);

  const remainingUnsynced = updated.filter((e) => !e.synced).length;

  console.log("[offlineEvents] Successfully synced events for match", matchId);

  return {
    syncedCount: unsynced.length,
    stillPending: remainingUnsynced,
  };
}
