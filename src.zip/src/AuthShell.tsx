// src/AuthShell.tsx
// Simple, temporary auth shell with hard-coded credentials + role.
// Later we can swap this to real Supabase auth without touching App.
// @ts-nocheck

import React, { useEffect, useState, FormEvent } from "react";
import App from "./App";

const PRESET_USERNAME = "vscor";
const PRESET_PASSWORD = "demo123";

type Role = "admin" | "scorer";

type StoredAuth = {
  username: string;
  role: Role;
};

export default function AuthShell() {
  const [checking, setChecking] = useState(true);
  const [auth, setAuth] = useState<StoredAuth | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Form state (only used before login)
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("admin");

  // On load, check localStorage so refresh keeps you logged in
  useEffect(() => {
    try {
      const raw = localStorage.getItem("vscor_auth");
      if (raw) {
        const parsed: StoredAuth = JSON.parse(raw);
        if (parsed?.username && parsed?.role) {
          setAuth(parsed);
        }
      }
    } catch (e) {
      console.warn("[AuthShell] could not read auth from localStorage", e);
    } finally {
      setChecking(false);
    }
  }, []);

  const handleLogin = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    if (username === PRESET_USERNAME && password === PRESET_PASSWORD) {
      const payload: StoredAuth = { username, role };
      try {
        localStorage.setItem("vscor_auth", JSON.stringify(payload));
      } catch (e) {
        console.warn("[AuthShell] unable to save auth to localStorage", e);
      }
      setAuth(payload);
    } else {
      setError("Invalid username or password.");
    }
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem("vscor_auth");
    } catch (e) {
      console.warn("[AuthShell] unable to clear auth from localStorage", e);
    }
    setAuth(null);
    setUsername("");
    setPassword("");
    setRole("admin");
  };

  // Small loader while we check localStorage
  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100">
        <div className="flex flex-col items-center gap-2">
          <div className="w-8 h-8 rounded-full border-2 border-purple-500 border-t-transparent animate-spin" />
          <p className="text-xs text-slate-400">Loading VScor…</p>
        </div>
      </div>
    );
  }

  // Login screen
  if (!auth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100 px-4">
        <div className="w-full max-w-xs bg-slate-900/80 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-9 h-9 rounded-2xl bg-purple-600 flex items-center justify-center text-sm font-semibold">
              VS
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.15em] text-slate-400">
                VScor
              </p>
              <h1 className="text-sm font-semibold text-slate-50">
                Scoring Console Login
              </h1>
            </div>
          </div>

          <form className="space-y-3" onSubmit={handleLogin}>
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-300">
                Username
              </label>
              <input
                className="w-full rounded-2xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-slate-100 outline-none focus:ring-2 focus:ring-purple-500"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="vscor"
                autoComplete="username"
                name="username"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-300">
                Password
              </label>
              <input
                className="w-full rounded-2xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-slate-100 outline-none focus:ring-2 focus:ring-purple-500"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="demo123"
                autoComplete="current-password"
                name="password"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-300">
                Role
              </label>
              <select
                className="w-full rounded-2xl bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-slate-100 outline-none focus:ring-2 focus:ring-purple-500"
                value={role}
                onChange={(e) => setRole(e.target.value as Role)}
                name="role"
              >
                <option value="admin">Admin</option>
                <option value="scorer">Scorer</option>
              </select>
              <p className="text-[10px] text-slate-500 mt-1">
                For now this is just a flag; later we’ll use it to gate screens
                with real Supabase auth.
              </p>
            </div>

            {error && (
              <p className="text-[11px] text-red-400 bg-red-950/40 border border-red-900/60 rounded-2xl px-3 py-1.5">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="w-full mt-1 rounded-2xl bg-purple-600 hover:bg-purple-500 active:bg-purple-700 px-3 py-2 text-xs font-semibold text-white transition"
            >
              Enter VScor
            </button>

            <p className="text-[10px] text-slate-500 text-center mt-1">
              Demo login:{" "}
              <span className="font-mono">vscor / demo123</span>
            </p>
          </form>
        </div>
      </div>
    );
  }

  // Authenticated: show app + a small logout chip
  return (
    <div className="relative">
      <div className="absolute top-3 right-3 z-20">
        <button
          onClick={handleLogout}
          className="px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-700 text-[11px] text-slate-100 hover:bg-slate-800 active:bg-slate-950 transition"
        >
          Logout ({auth.role})
        </button>
      </div>
      <App authUser={auth.username} authRole={auth.role} />
    </div>
  );
}
